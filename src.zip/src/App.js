import StyledGlobal, { CorFundo } from "./styledGlobal";
import Home from "./pages/Home/Home";
import Details from "../../donuts/src/pages/Home/Home"
import { useState } from "react";


function App() {
  
  const[trocarDePagina, setTrocarDePagina] = useState("0")

  const changePage = (change) =>{
    setTrocarDePagina(change)
  }

  return (
    <>
      <CorFundo>
        <StyledGlobal />
        {trocarDePagina === "0"? (
          <Home pagina={()=> changePage("1")}/>
        ) : (
          <Details pagina={()=> changePage("0")}/>
        )}
        
      </CorFundo>
    
    </>
  );
}

export default App;
