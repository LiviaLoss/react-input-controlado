import styled from "styled-components"

export const BotaoEstilo = styled.a`
display: flex;
align-items: center;
justify-content: center;
color: #393939;

&:hover{
    width: 20vw
    height: 3.2vh;
    padding: 1vw;
    bprder-radius: 15px;
    bacground-color: #F9D03F;
    color: #696969;
}
`
