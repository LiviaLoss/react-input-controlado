import { DetalhesTitulo, TituloHeaderContainer } from "./styled"

function TituloHeader(){
    return(
        <TituloHeaderContainer> Some sweet of
            <DetalhesTitulo> Hapiness </DetalhesTitulo>
        </TituloHeaderContainer>
    )
}

export default TituloHeader