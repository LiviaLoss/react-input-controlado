import filtro from "../../assets/filtro.png"
import Botao from "../Botao/Botão"
import { ContainerNav } from "./styles"
// import Botao from "../../Botao/Botao"

function Nav(){

    return(
        <ContainerNav>
            <Botao titulo={"Donuts"}/>
            <Botao titulo={"Ice Cream"}/>
            <Botao titulo={"Bomboloni"}/>

            <img src={filtro} alt="filtro"/>

        </ContainerNav>
    )
}

export default Nav