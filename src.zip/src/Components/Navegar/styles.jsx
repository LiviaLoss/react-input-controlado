import styled from "styled-components"

export const ContainerNav = styled.nav`
display: flex;
justify-content: space-evenly;
align-items: center;
`