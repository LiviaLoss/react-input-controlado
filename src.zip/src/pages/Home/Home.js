import  Header from "../../Components/Header/Header";
import Nav from "../../Components/Navegar/Navegar.js";
import Card from "../../Components/Card/Card";
import TituloHeader from "../../Components/TituloHeader/TituloHeader";
import menu from "../../assets/menu.png";
import search from "../../assets/search.png"

import { SectionCard } from "./styled";


function Home(props) {

    return (

        <>
            <Header
            pagina={props.pagina}
            imgPrimeira={menu}
            imgSegunda={search}
            />

            <TituloHeader/>
            <Nav/>
            
            <SectionCard>
                <Card/>
                <Card/>
                <Card/>
                <Card/>
            </SectionCard>
        </>


    )
}


export default Home